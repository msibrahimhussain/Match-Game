import './index.css'

const Items = props => {
  const {projectDetails, onClk} = props
  const {id, thumbnailUrl} = projectDetails

  const onClkBtn = () => {
    onClk(id)
  }

  return (
    <>
      <li className="project-item-container">
        <button type="button" onClick={onClkBtn}>
          <img
            className="project-item-image"
            src={thumbnailUrl}
            alt="thumbnail"
          />
        </button>
      </li>
    </>
  )
}

export default Items
